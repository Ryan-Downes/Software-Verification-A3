
public class Test {
	
	public static void main(String[] args) {	
		int i0 = 0;
		int i1 = 1;
		int i2 = 1;

		while (i0 < 10) {
			if (i1 > 0) {
				i0 = i0 + i2;
			}
			else {
				i2 = i0;
			}
			i1 = i1 * i0;
		}

		i2 = i1;
		return;
	}
}
