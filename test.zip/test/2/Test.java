
public class Test {
	
	public static void main(String[] args) {	
		int i = 0;
		int j = 1;

		i = 1 + j;
		j = i * i;

		i = i * j;
		j = i + 1;
		
		return;
	}
}
