
public class Test {
	
	public static void main(String[] args) {	
		int i0 = 0;
		int i1 = 1;
		int i2 = 0;
		
		i2 = i0 + i1;
		i0 = i2 - i0;
		i1 = i2 + i0;
		i0 = i1 - i2;
		
		return;
	}
}
