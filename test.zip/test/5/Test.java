
public class Test {
	
	public static void main(String[] args) {	
		int i = 100;
		int j = 50;

		int a = 0;
		int b = 1;

		while (i > 10) {
			while (j > 0) {
				a = a + b;
			}
			b = a * b;
		}

		a = a + b ;
		return;
	}
}
