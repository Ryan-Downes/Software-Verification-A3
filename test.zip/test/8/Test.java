
public class Test {
	
	public static void main(String[] args) {	
		int i = 0;
		int j = 1;
		int res = 0;

		if (i > 0) {
			res = j + 1;
			
		}
		else {
			res = j * 2;
		}
		res = res + i;
		return;
	}
}
