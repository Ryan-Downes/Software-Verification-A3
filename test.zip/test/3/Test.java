
public class Test {
	
	public static void main(String[] args) {	
		int a = 784;
		int b = 1506;
		int res = 1;
		while (a > 0) {
			int n = a%b;
			b = a;
			a = n;
		}
		res = b;
		return;
	}
}
